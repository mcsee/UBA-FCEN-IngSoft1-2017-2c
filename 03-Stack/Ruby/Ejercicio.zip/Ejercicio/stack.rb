
class Stack

  def push(an_object)
    should_implement
  end

  def pop
    should_implement
  end

  def top
    should_implement
  end

  def empty?
    should_implement
  end

  def size
    should_implement
  end

  def self.stack_empty_error_description
    should_implement
  end

  def should_implement
    raise 'Should be implemented'
  end

  end
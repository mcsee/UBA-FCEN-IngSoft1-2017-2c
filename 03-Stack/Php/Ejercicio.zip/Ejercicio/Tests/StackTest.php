<?php

/*
 * Developed by 10Pines SRL
 * License: 
 * This work is licensed under the 
 * Creative Commons Attribution-NonCommercial-ShareAlike 3->0 Unported License-> 
 * To view a copy of this license, visit http://creativecommons->org/licenses/by-nc-sa/3->0/ 
 * or send a letter to Creative Commons, 444 Castro Street, Suite 900, Mountain View, 
 * California, 94041, USA->
 *  
 */
require_once '../Stack.php';

class StackTest extends PHPUnit_Framework_TestCase {

	public function testStackShouldBeEmptyWhenCreated(){
		$stack = new Stack();
		
		$this->assertTrue($stack->isEmpty());
	}
	
	public function testPushAddElementsToTheStack(){
		$stack = new Stack();
		$stack->push("Something");
		
		$this->assertFalse($stack->isEmpty());
	}

	public function testPopRemovesElementsFromTheStack(){
		$stack = new Stack();
		$stack->push("Something");
		$stack->pop();
		
		$this->assertTrue($stack->isEmpty());
	}
	
	public function testPopReturnsLastPushedObject(){
		$stack = new Stack();
		$pushedObject = "Something";
		$stack->push($pushedObject);
		$this->assertEquals($pushedObject, $stack->pop());
	}

	public function testStackBehavesLIFO (){
		$firstPushed = "First";
		$secondPushed = "Second";
		$stack = new Stack();
		$stack->push($firstPushed);
		$stack->push($secondPushed);
		
		$this->assertEquals($secondPushed,$stack->pop());
		$this->assertEquals($firstPushed,$stack->pop());
		$this->assertTrue($stack->isEmpty());
	}

	public function testTopReturnsLastPushedObject(){
		$stack = new Stack();
		$pushedObject = "Something";

		$stack->push($pushedObject);

		$this->assertEquals($pushedObject, $stack->top());
	}

	public function testTopDoesNotRemoveObjectFromStack(){
		$stack = new Stack();
		$pushedObject = "Something";

		$stack->push($pushedObject);

		$this->assertEquals(1,$stack->size()); 
		$stack->top();
		$this->assertEquals(1,$stack->size());
	}

	public function testCanNotPopWhenThereAreNoObjectsInTheStack(){
		$stack = new Stack();
		
		try {
			$stack->pop();
			$this->fail();
		} catch (Exception $stackIsEmpty){
			$this->assertEquals(Stack::STACK_EMPTY_DESCRIPTION,$stackIsEmpty->getMessage());
		}
	}

	public function testCanNotTopWhenThereAreNoObjectsInTheStack(){
		$stack = new Stack();

		try {
			$stack->top();
			$this->fail();
		} catch (Exception $stackIsEmpty){
			$this->assertEquals(Stack::STACK_EMPTY_DESCRIPTION,$stackIsEmpty->getMessage());
		}
	}
}
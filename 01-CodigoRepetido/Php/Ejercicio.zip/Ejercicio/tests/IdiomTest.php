<?php
/*
 * Developed by 10Pines SRL
 * License: 
 * This work is licensed under the 
 * Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported License. 
 * To view a copy of this license, visit http://creativecommons.org/licenses/by-nc-sa/3.0/ 
 * or send a letter to Creative Commons, 444 Castro Street, Suite 900, Mountain View, 
 * California, 94041, USA.
 *  
 */

require_once '../CustomerBook.php';

class IdiomTest extends PHPUnit_Framework_TestCase {
	
    protected $customerBook;

    public function setUp(){
            $this->customerBook = new CustomerBook ();
    }


    public function testAddingCustomerShouldNotTakeMoreThan50Milliseconds(){

        $timeBeforeRunning = microtime(TRUE);
        $this->customerBook->addCustomerNamed("John Lennon");
        $timeAfterRunning = microtime(TRUE);

        $this->assertTrue( ($timeAfterRunning-$timeBeforeRunning) < 50 );
    }

    public function testRemovingCustomerShouldNotTakeMoreThan100Milliseconds(){
        $paulMcCartney = "Paul McCartney";

        $this->customerBook->addCustomerNamed($paulMcCartney);

        $timeBeforeRunning = microtime(TRUE);
        $this->customerBook->removeCustomerNamed($paulMcCartney);
        $timeAfterRunning = microtime(TRUE);

        $this->assertTrue( ($timeAfterRunning-$timeBeforeRunning) < 100 );
    }
	
    public function testCanNotAddACustomerWithEmptyName (){

        try {
            $this->customerBook->addCustomerNamed("");
            $this->fail();
        } catch (RuntimeException $exception) {
            $this->assertEquals($exception->getMessage(),CustomerBook::CUSTOMER_NAME_EMPTY);
            $this->assertTrue($this->customerBook->isEmpty());
        }
    }

    public function testCanNotRemoveNotAddedCustomers (){

        try {
            $this->customerBook->removeCustomerNamed("John Lennon");
            $this->fail();
        } catch (InvalidArgumentException $exception) {
            $this->assertEquals($exception->getMessage(),CustomerBook::INVALID_CUSTOMER_NAME);
            $this->assertEquals(0,$this->customerBook->numberOfCustomers());
        }
    }
 
}
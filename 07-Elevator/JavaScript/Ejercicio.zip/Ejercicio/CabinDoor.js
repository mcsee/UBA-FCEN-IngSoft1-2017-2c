/*
 * Developed by 10Pines SRL
 * License: 
 * This work is licensed under the 
 * Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported License. 
 * To view a copy of this license, visit http://creativecommons.org/licenses/by-nc-sa/3.0/ 
 * or send a letter to Creative Commons, 444 Castro Street, Suite 900, Mountain View, 
 * California, 94041, USA.
 *  
 */

require ('./Object.js');
require ('./Motor.js');

CabinDoor = function (cabin) {
    this.cabin = cabin;
    this.motor = new Motor();
};

CabinDoor.SENSOR_DESINCRONIZED = "Sensor de puerta desincronizado";

//State
CabinDoor.prototype.isOpened = function () {
    this.shouldBeImplementedBySubclass();
};

CabinDoor.prototype.isOpening = function () {
    this.shouldBeImplementedBySubclass();
};

CabinDoor.prototype.isClosing = function () {
    this.shouldBeImplementedBySubclass();
};

CabinDoor.prototype.isClosed = function () {
    this.shouldBeImplementedBySubclass();
};

//Actions
CabinDoor.prototype.startClosing = function () {
    this.cabin.assertMotorIsNotMoving();

    this.motor.moveClockwise();
};

CabinDoor.prototype.startOpening = function () {
    this.cabin.assertMotorIsNotMoving();

    this.motor.moveCounterClockwise();
};

//Sensor events
CabinDoor.prototype.closed = function () {
    this.shouldBeImplementedBySubclass();
};

CabinDoor.prototype.opened = function () {
    this.shouldBeImplementedBySubclass();
};

//Button events
CabinDoor.prototype.open = function () {
    this.shouldBeImplementedBySubclass();
};

CabinDoor.prototype.close = function () {
    this.shouldBeImplementedBySubclass();
};

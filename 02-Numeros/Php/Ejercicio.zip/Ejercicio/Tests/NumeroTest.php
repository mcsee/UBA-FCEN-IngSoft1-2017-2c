 <?php

/*
 * Developed by 10Pines SRL
 * License: 
 * This work is licensed under the 
 * Creative Commons Attribution-NonCommercial-ShareAlike 3->0 Unported License-> 
 * To view a copy of this license, visit http://creativecommons->org/licenses/by-nc-sa/3->0/ 
 * or send a letter to Creative Commons, 444 Castro Street, Suite 900, Mountain View, 
 * California, 94041, USA->
 *  
 */
require_once '../Numero.php';
require_once '../Entero.php';
require_once '../Fraccion.php';

class TestNumero extends PHPUnit_Framework_TestCase {

	protected $cero;
	protected $uno;
	protected $dos;
	protected $tres;
	protected $cuatro;
	protected $cinco;
	
	protected $unQuinto;
	protected $dosQuintos;
	protected $tresQuintos;
	protected $dosVeinticincoavos;
	protected $unMedio;
	protected $cincoMedios;
	protected $seisQuintos;
	protected $cuatroMedios;
	protected $dosCuartos;

	public function setUp (){
		//inicializar los numeros
		
		$this->cero = new Entero(0);
		$this->uno = new Entero(1);
		$this->dos = new Entero(2);
		$this->tres = new Entero(3);
		$this->cuatro = new Entero(4);
		$this->cinco = new Entero(5);

		$this->unQuinto = $this->uno->dividido($this->cinco);
		$this->dosQuintos = $this->dos->dividido($this->cinco);
		$this->tresQuintos = $this->tres->dividido($this->cinco);
		$this->dosVeinticincoavos = $this->dos->dividido(new Entero(25));
		$this->unMedio = $this->uno->dividido($this->dos);
		$this->cincoMedios = $this->cinco->dividido($this->dos);
		$this->seisQuintos = (new Entero(6))->dividido($this->cinco);
		$this->cuatroMedios = $this->cuatro->dividido($this->dos);
		$this->dosCuartos = $this->dos->dividido($this->cuatro);
		
	}
	 
	public function testEsCeroDevuelveTrueSoloParaElCero () {
		$this->assertTrue ($this->cero->esCero());
		$this->assertFalse ($this->uno->esCero());
	}

	public function testEsUnoDevuelveTrueSoloParaElUno () {
		$this->assertTrue ($this->uno->esUno());
		$this->assertFalse ($this->cero->esUno());
	}

	public function testSumaDeEnteros(){
		$this->assertEquals ($this->dos,$this->uno->mas($this->uno));
	}
	
	public function testMultiplicacionDeEnteros(){
		$this->assertEquals($this->cuatro, $this->dos->por($this->dos));
	}

	public function testDivisionDeEnteros(){
		$this->assertEquals($this->uno, $this->dos->dividido($this->dos));
	}
	
	public function testSumaDeFracciones(){
		$sieteDecimos = (new Entero(7))->dividido(new Entero(10));
		$this->assertEquals ($sieteDecimos,$this->unQuinto->mas($this->unMedio));
		/* 
		 * La suma de fracciones es:
		 * 
		 * a/b + c/d = (a->d + c->b) / (b->d)
		 * 
		 * SI ESTAN PENSANDO EN LA REDUCCION DE FRACCIONES NO SE PREOCUPEN!
		 * TODAVIA NO SE ESTA TESTEANDO ESE CASO
		 */
	}

	public function testMultiplicacionDeFracciones(){
		$this->assertEquals ($this->dosVeinticincoavos,$this->unQuinto->por($this->dosQuintos));
		/* 
		 * La multiplicación de fracciones es:
		 * 
		 * (a/b) * (c/d) = (a->c) / (b->d)
		 * 
		 * SI ESTAN PENSANDO EN LA REDUCCION DE FRACCIONES NO SE PREOCUPEN!
		 * TODAVIA NO SE ESTA TESTEANDO ESE CASO
		 */
	}
	
	public function testDivisionDeFracciones(){
		$this->assertEquals ($this->cincoMedios,$this->unMedio->dividido($this->unQuinto));
		/* 
		 * La división de fracciones es:
		 * 
		 * (a/b) / (c/d) = (a->d) / (b->c)
		 * 
		 * SI ESTAN PENSANDO EN LA REDUCCION DE FRACCIONES NO SE PREOCUPEN!
		 * TODAVIA NO SE ESTA TESTEANDO ESE CASO
		 */
	}

	/* 
	 * Ahora empieza lo lindo! - Primero hacemos que se puedan sumar enteros con fracciones
	 * y fracciones con enteros 
	 */
	public function testSumaDeEnteroYFraccion(){
		$this->assertEquals ($this->seisQuintos,$this->uno->mas($this->unQuinto));
	}
	
	public function testSumaDeFraccionYEntero(){
		$this->assertEquals ($this->seisQuintos,$this->unQuinto->mas($this->uno));
	}

	/* 
	 * Hacemos lo mismo para la multipliación
	 */
	public function testMultiplicacionDeEnteroPorFraccion(){
		$this->assertEquals($this->dosQuintos,$this->dos->por($this->unQuinto));
	}
	
	public function testMultiplicacionDeFraccionPorEntero(){
		$this->assertEquals($this->dosQuintos,$this->unQuinto->por($this->dos));
	}
	
	/* 
	 * Hacemos lo mismo para la division
	 */
	public function testDivisionDeEnteroPorFraccion(){
		$this->assertEquals($this->cincoMedios,$this->uno->dividido($this->dosQuintos));
	}

	public function testDivisionDeFraccionPorEntero(){
		$this->assertEquals($this->dosVeinticincoavos,$this->dosQuintos->dividido($this->cinco));
	}
	
	/* 
	 * Ahora si empezamos con problemas de reducción de fracciones
	 */
	public function testUnaFraccionPuedeSerIgualAUnEntero(){
		$this->assertEquals($this->dos,$this->cuatroMedios);
	}
	public function testLasFraccionesAparentesSonIguales(){
		$this->assertEquals($this->unMedio,$this->dosCuartos);
		/*
		 * Las fracciones se reducen utilizando el maximo comun divisor (mcd)
		 * Por lo tanto, para a/b, sea c = mcd (a,b) => a/b reducida es:
		 * (a/c) / (b/c)
		 * 
		 * Por ejemplo: a/b = 2/4 entonces c = 2-> Por lo tanto 2/4 reducida es:
		 * (2/2) / (4/2) = 1/2
		 * 
		 * Para obtener el mcd pueden usar el algoritmo de Euclides que es:
		 * 
		 * mcd (a,b) = 
		 * 		si b = 0 --> a
		 * 		si b != 0 -->mcd(b, restoDeDividir(a,b))
		 * 	
		 * Ejemplo:
		 * mcd(2,4) ->
		 * mcd(4,restoDeDividir(2,4)) ->
		 * mcd(4,2) ->
		 * mcd(2,restoDeDividir(4,2)) ->
		 * mcd(2,0) ->
		 * 2
		 */
	}
	
	public function testLaSumaDeFraccionesPuedeDarEntero(){
		$this->assertEquals ($this->uno,$this->unMedio->mas($this->unMedio));
	}
	
	public function testLaMultiplicacionDeFraccionesPuedeDarEntero(){
		$this->assertEquals($this->dos,$this->cuatro->por($this->unMedio));
	}
	
	public function testLaDivisionDeEnterosPuedeDarFraccion(){
		$this->assertEquals($this->unMedio, $this->dos->dividido($this->cuatro));
	}

	public function testLaDivisionDeFraccionesPuedeDarEntero(){
		$this->assertEquals($this->uno, $this->unMedio->dividido($this->unMedio));
	}
	
	public function testNoSePuedeDividirEnteroPorCero(){
		try {
			$this->uno->dividido($this->cero);
			$this->fail();
		}
		catch (RuntimeException $e) {
			$this->assertEquals(Numero::DESCRIPCION_DE_ERROR_NO_SE_PUEDE_DIVIDIR_POR_CERO,$e->getMessage());
		}
	}

	public function testNoSePuedeDividirFraccionPorCero(){
		try {
			$this->unQuinto->dividido($this->cero);
			$this->fail();
		}
		catch (RuntimeException $e) {
			$this->assertEquals(Numero::DESCRIPCION_DE_ERROR_NO_SE_PUEDE_DIVIDIR_POR_CERO,$e->getMessage());
		}
	}

	// Este test puede ser redundante dependiendo de la implementación realizada 
	public function testNoSePuedeCrearFraccionConDenominadorCero(){
		try {
			$this->crearFraccionCon($this->uno,$this->cero);
			$this->fail();
		}
		catch (RuntimeException $e) {
			$this->assertEquals(Numero::DESCRIPCION_DE_ERROR_NO_SE_PUEDE_DIVIDIR_POR_CERO,$e->getMessage());
		}
	}

	public function crearFraccionCon($numerador,$denominador) {
		return $numerador->dividido($denominador);
	}

}
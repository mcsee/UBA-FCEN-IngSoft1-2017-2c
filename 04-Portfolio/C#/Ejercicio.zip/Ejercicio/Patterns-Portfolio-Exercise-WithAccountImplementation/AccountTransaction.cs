﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Patterns_Portfolio_Exercise_WithAccountImplementation
{
    interface AccountTransaction
    {
        double value();
    }
}

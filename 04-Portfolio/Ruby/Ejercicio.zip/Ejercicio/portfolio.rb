require './summarizing_account'

class Portfolio < SummarizingAccount

  def self.create_with(account1,account2)
    self.should_implement
  end

  def self.ACCOUNT_ALREADY_MANAGED
    'Account already managed'
  end

  def add_account(account)
    self.should_implement
  end
end
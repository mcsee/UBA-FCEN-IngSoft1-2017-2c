class Object
  def should_implement
    raise 'Should implement'
  end
end
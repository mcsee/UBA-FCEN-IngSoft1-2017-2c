/*
 * Developed by 10Pines SRL
 * License:
 * This work is licensed under the
 * Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported License.
 * To view a copy of this license, visit http://creativecommons.org/licenses/by-nc-sa/3.0/
 * or send a letter to Creative Commons, 444 Castro Street, Suite 900, Mountain View,
 * California, 94041, USA.
 *
 */
require('./SummarizingAccount.js');

Portfolio = function () {
    SummarizingAccount.call(this);
    this._summarizingAccounts = [];
};

Portfolio.prototype = Object.create(SummarizingAccount.prototype);
Portfolio.prototype.ACCOUNT_ALREADY_MANAGED = "La cuenta ya está manejada por otro portfolio";

Portfolio.createWith = function (anAccount,anotherAccount) {
    this.shouldImplement();
};

Portfolio.prototype.balance = function () {
    this.shouldImplement();
};

Portfolio.prototype.registers = function (transaction) {
    this.shouldImplement();
};

Portfolio.prototype.manages = function (account) {
    this.shouldImplement();
};

Portfolio.prototype.transactions = function () {
    this.shouldImplement();
};

Portfolio.prototype.addAccount = function (account) {
    this.shouldImplement();
};

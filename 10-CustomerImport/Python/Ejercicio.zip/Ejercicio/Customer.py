from sqlalchemy import Table, Column, String, Integer, ForeignKey
from sqlalchemy.orm import relationship, backref
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

Base = declarative_base()

class Address(Base):
    __tablename__ = 'addresses'

    id = Column(Integer, primary_key=True)
    streetName = Column(String)
    streetNumber = Column(Integer)
    town = Column(String)
    zipCode = Column(Integer)
    province = Column(String)
    customer_id = Column(Integer, ForeignKey('customers.id'))

    def getStreetName(self):
        return self.streetName
    
    def setStreetName(self,newStreetName):
        self.streetName = newStreetName
        
    def getStreetNumber(self):
        return self.streetNumber
    
    def setStreetNumber(self,newStreetNumber):
        self.streetNumber = newStreetNumber
        
    def getTown(self):
        return self.town
    
    def setTown(self, town):
        self.town = town
    
    def getZipCode(self):
        return self.zipCode
    
    def setZipCode(self,zipCode):
        self.zipCode = zipCode
    
    def getProvince(self):
        return self.province
    
    def setProvince(self, province):
        self.province = province

class Customer(Base):
    __tablename__ = 'customers'
    
    id = Column(Integer, primary_key=True)
    firstName = Column(String)
    lastName = Column(String)
    identificationType = Column(String)
    identificationNumber = Column(String)
    addresses = relationship("Address", backref="customer")
    
    def getFirstName(self):
        return self.firstName

    def setFirstName(self,firstName):
        self.firstName = firstName

    def getLastName(self):
        return self.lastName

    def setLastName(self,lastName):
        self.lastName = lastName

    def getIdentificationType(self):
        return self.identificationType

    def setIdentificationType(self,identificationType):
        self.identificationType = identificationType

    def getIdentificationNumber(self):
        return self.identificationNumber

    def setIdentificationNumber(self,identificationNumber):
        self.identificationNumber = identificationNumber
    
    def addAddress(self,anAddress):
        self.addresses.append(anAddress)
        
    def getAddresses(self):
        return self.addresses

    @staticmethod
    def importCustomers():
        
        inputFile = open("resources/input.txt")
        
        engine = create_engine('sqlite:///db.sqlite',echo=True)
        Base.metadata.create_all(engine) 
        Session = sessionmaker(bind=engine)
        session = Session()

        
        for line in inputFile:
            if line.startswith("C"):
                customerData = line.split(",")
                newCustomer = Customer()
                newCustomer.setFirstName(customerData[1])
                newCustomer.setLastName(customerData[2])
                newCustomer.setIdentificationType(customerData[3])
                newCustomer.setIdentificationNumber(customerData[3].rstrip())
                session.add(newCustomer)
            elif line.startswith("A"):
                addressData = line.split(",")
                newAddress = Address()
    
                newCustomer.addAddress(newAddress)
                newAddress.setStreetName(addressData[1])
                newAddress.setStreetNumber(int(addressData[2]))
                newAddress.setTown(addressData[3])
                newAddress.setZipCode(int(addressData[4]))
                newAddress.setProvince(addressData[3].rstrip())
            
        session.commit()
        session.close()
        
        inputFile.close()
   
    
Customer.importCustomers()

#Algunos mensajes utiles de sqlalchemy
# Dropear una base:
#   Base.metadata.drop_all(engine)
# Contar la cantidad de files de una tabla:
#   self.session.query(CLASE).count()
# Hacer un select con condiciones:
#   self.session.query(CLASE). \
#            filter(CONDICION1). \
#            filter(CONDICION2).\
#            all()  <-- trae todos los que cumplen con esas condiciones



